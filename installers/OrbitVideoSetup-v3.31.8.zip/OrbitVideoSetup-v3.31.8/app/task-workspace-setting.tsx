'use client';
import {confirmAction} from './confirm-action';
import {useState} from 'react';
import {projectApi} from './project-management';
export function TaskWorkspaceSetting({project,enabled,onChanged}:{project:number;enabled:boolean;onChanged:()=>void}){const [busy,setBusy]=useState(false),[error,setError]=useState('');return <section className="panel task-workspace-setting"><h3>当前项目任务工作区</h3><p>仅影响此项目：左右联动任务库、人员悬浮卡片及一母版一主产品规则。其他项目保持原流程。</p><label><input type="checkbox" checked={enabled} disabled={busy} onChange={async e=>{const value=e.target.checked;if(!await confirmAction(value?'仅为当前项目启用任务工作区？历史资料会保留。':'停用当前项目任务工作区？任务记录仍保留。'))return;setBusy(true);try{await projectApi(`/api/projects/${project}/task-workspace`,{enabled:value},'PUT');onChanged();}catch(e){setError((e as Error).message);}finally{setBusy(false);}}}/>启用本项目任务工作区</label>{error?<p role="alert">{error}</p>:null}</section>;}
