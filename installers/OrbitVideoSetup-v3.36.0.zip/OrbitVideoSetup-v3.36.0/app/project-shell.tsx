"use client";
import {EmployeeSyncAdmin} from './employee-sync-admin';
import {AdminMaintenance} from './admin-maintenance';
import {canLeavePage} from './page-leave-guard';
import {confirmAction} from './confirm-action';
import {TransferStation} from './transfer-station';
import {useCallback,useEffect,useState,useRef} from 'react';
import {ModuleView} from './modules';
import {useBusinessContext,clearBusinessContext,readBusinessContext} from './business-context';
import {installProjectFetch} from '@/lib/client-project-fetch';
import {permissionGranted} from '@/lib/permissions';
import {ProjectManagement,projectApi} from './project-management';
import {DashboardNoticeDialog} from './workbench-widgets';
import {ProjectDashboard} from './project-dashboard';
import {ProjectStatistics} from './project-statistics';
import {ViewportTables} from './viewport-tables';
import {CrossWorkspace} from './cross-workspace';
import {TargetPublishing} from './target-publishing';
type Project={badgeUnavailable?:boolean;badge?:{modules?:Record<string,{pending:number;updates:number}>;pending:number;updates:number;total:number};projectType?:string;id:number;name:string;code:string;groups:{id:number;name:string}[];capabilities:Record<string,boolean>};
type User={id:number;displayName:string;roleCode:string;permissions:string[]};
type NoticeTask={id:number;title:string;requiresReply:boolean;actionRequired:boolean};
export function ProjectShell(){
 installProjectFetch();
 const workspaceRef=useRef<HTMLElement>(null),topbarRef=useRef<HTMLElement>(null);
 useEffect(()=>{const bar=topbarRef.current,workspace=workspaceRef.current;if(!bar||!workspace)return;const update=()=>workspace.style.setProperty('--project-topbar-height',Math.ceil(bar.getBoundingClientRect().height)+'px');update();const observer=new ResizeObserver(update);observer.observe(bar);return()=>observer.disconnect();},[]);
 const {context,setContext}=useBusinessContext();const [projects,setProjects]=useState<Project[]>([]),[user,setUser]=useState<User|null>(null),[nav,setNav]=useState('系统首页'),[epoch,setEpoch]=useState(0),[message,setMessage]=useState(''),[error,setError]=useState(''),[badgeWarning,setBadgeWarning]=useState(false),[targetCode,setTargetCode]=useState(''),[noticeTarget,setNoticeTarget]=useState<number|null>(null),[noticeTasks,setNoticeTasks]=useState<NoticeTask[]>([]);
 const [canMaintain,setCanMaintain]=useState(false);
 useEffect(()=>{let live=true;void projectApi('/api/admin/sync-control?probe=1').then(d=>{if(live)setCanMaintain(d.master===true);}).catch(()=>{if(live)setCanMaintain(false);});return()=>{live=false;};},[user?.id]);
 const [messageTone,setMessageTone]=useState<'success'|'error'>('success');
 useEffect(()=>{if(!message)return;const timer=setTimeout(()=>setMessage(''),messageTone==='error'?6000:3000);return()=>clearTimeout(timer);},[message,messageTone]);
 const [collapsed,setCollapsed]=useState(false);
 useEffect(()=>{const frame=requestAnimationFrame(()=>{if(window.matchMedia('(max-width:760px)').matches)setCollapsed(true);});return()=>cancelAnimationFrame(frame);},[]);
 const [icons,setIcons]=useState<Record<string,string>>({});
 const refreshSequence=useRef(0);
 const refresh=useCallback(async()=>{const sequence=++refreshSequence.current;const [catalog,auth]=await Promise.allSettled([projectApi('/api/projects'),projectApi('/api/auth/me')]);if(sequence!==refreshSequence.current)return;const failures:string[]=[];if(catalog.status==='fulfilled'&&Array.isArray(catalog.value?.projects)){const data=catalog.value;setProjects(data.projects);setBadgeWarning(data.projects.some((p:Project)=>p.badgeUnavailable));const current=readBusinessContext();if(current&&!data.projects.some((project:Project)=>project.id===current.accountId)){clearBusinessContext();setNav('系统首页');setEpoch(value=>value+1);}}else failures.push(catalog.status==='rejected'?catalog.reason.message:'项目列表接口格式异常，请重试');if(auth.status==='fulfilled'&&auth.value?.user&&Array.isArray(auth.value.user.permissions))setUser(auth.value.user);else{failures.push(auth.status==='rejected'?auth.reason.message:'账号信息接口格式异常，请重新登录');if(auth.status==='rejected'&&auth.reason.details?.status===401)setUser(null);}setError(failures.join('；'));},[]);
 useEffect(()=>{const first=setTimeout(()=>void refresh().catch(error=>setError(error.message)),0);const timer=setInterval(()=>void refresh().catch(()=>{}),5000);return()=>{clearTimeout(first);clearInterval(timer);};},[refresh]);
 useEffect(()=>{const revoke=()=>{clearBusinessContext();setNav('系统首页');setTargetCode('');setNoticeTarget(null);setEpoch(value=>value+1);setMessage('项目访问资格已取消');setMessageTone('error');};window.addEventListener('orbit-project-access-revoked',revoke);return()=>window.removeEventListener('orbit-project-access-revoked',revoke);},[]);
 const can=(permission:string)=>permissionGranted(user?.permissions??[],permission);
 const project=projects.find(project=>project.id===context?.accountId);
 async function enter(id:number){const next=projects.find(project=>project.id===id);if(!next)return;if(!await confirmAction(`确定${context?'切换到':'进入'}“${next.name}”项目吗？未保存的内容将自动清除，随后进入项目工作台。`))return;if(!await canLeavePage())return;setNoticeTarget(null);sessionStorage.removeItem('orbit:content-pool-state');setContext({accountId:next.id,accountCode:next.code,accountName:next.name,platformCode:'',platformName:'',groupId:null,groupName:null});setTargetCode('');setNav('项目工作台');setEpoch(value=>value+1);setMessage('');}
 async function global(name:string,target=''){if(!await canLeavePage())return;if(name==='产品包管理')name='产品管理';if(name==='母版审核'){name='母版库';target='pending';}else if(name==='产品包审核'){name='产品管理';target='pending';}setTargetCode(target);setNav(name);setEpoch(value=>value+1);}
 const notify=useCallback((message:string,tone?:'success'|'error')=>{setMessage(message);setMessageTone(tone??(/失败|错误|无权|没有.*权限|不能|请先|不存在|缺失|未连接|无效|尚未/.test(message)?'error':'success'));},[]);
 const canNotice=Boolean(can('notice.view'));
 const loadNotices=useCallback(async()=>{if(!canNotice)return;const rules=encodeURIComponent(JSON.stringify([{field:'readState',operator:'eq',value:'待处理',join:'and'}]));const data=await projectApi('/api/notices?rules='+rules);setNoticeTasks(data.items.filter((row:NoticeTask)=>row.actionRequired).slice(0,5));},[canNotice]);
 useEffect(()=>{const first=setTimeout(()=>void loadNotices().catch(()=>{}),0);const timer=setInterval(()=>void loadNotices().catch(()=>{}),30000);return()=>{clearTimeout(first);clearInterval(timer);};},[loadNotices]);
 const globalNav=[['系统首页',''],['通知公告','notice.view'],['工作报备','report.view'],['项目管理','business.accounts'],['组织与权限','admin.view'],['报备模板','report.template_manage'],['配置中心','admin.settings'],['操作日志','audit.view'],['员工同步管理','__master'],['全平台业务清理','__master']];
 const projectNav=project?.projectType==='cross_border'?[['项目工作台',''],['线索库','cross'],['母版库','cross'],['产品管理','cross'],['中转站','transfer']]:[['项目工作台',''],['素材中心','assets'],['产品库','products'],['内容池','content'],['审核中心','review'],['发布管理','publishing'],['版本管理','versions'],['数据统计','analytics'],['中转站','transfer']];

 const globalPage=globalNav.some(([name])=>name===nav);
 const visibleGlobal=globalNav.filter(([name,key])=>!key||(key==='__master'?canMaintain:can(key))||(name==='工作报备'&&(can('report.receive')||can('report.cc'))));
 const globalButton=([name]:string[])=><button className={nav===name?'active':''} aria-current={nav===name?'page':undefined} key={name} onClick={()=>global(name)}><span className="project-nav-label">{name}</span><span className="module-indicators">{project?.badge?.modules?.[name]?.pending?<span className="module-task-count">{project.badge.modules[name].pending}</span>:null}{project?.badge?.modules?.[name]?.updates?<span className="module-unread-dot" aria-label="有未读更新"/>:null}</span></button>;
 return <main className={collapsed?"project-app navigation-collapsed":"project-app"}><aside className="project-sidebar" id="primary-navigation" hidden={collapsed}><h1>内容中台</h1>
 <nav className="project-global-nav" aria-label="全局事项">{visibleGlobal.slice(0).filter(([name])=>['系统首页','通知公告','工作报备'].includes(name)).map(globalButton)}</nav>
 <section className="project-navigation" aria-label="项目导航"><div className="project-tab-column"><small id="project-tabs-label">项目</small><div className="project-tabs" role="tablist" aria-labelledby="project-tabs-label" aria-orientation="vertical">{projects.map(item=><button id={`project-tab-${item.id}`} role="tab" aria-selected={project?.id===item.id} aria-controls="project-module-navigation" tabIndex={!project||project.id===item.id?0:-1} key={item.id} title={item.name} onClick={()=>enter(item.id)} onKeyDown={event=>{const index=projects.findIndex(row=>row.id===item.id);const offset=event.key==='ArrowDown'?1:event.key==='ArrowUp'?-1:0;if(offset||event.key==='Home'||event.key==='End'){event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?projects.length-1:(index+offset+projects.length)%projects.length;document.getElementById(`project-tab-${projects[next].id}`)?.focus();}else if(event.key===' '){event.preventDefault();enter(item.id);}}}><span className="project-tab-name">{item.name}</span>{item.badge&&item.badge.total>0?<span className="project-nav-count" aria-label={`待操作${item.badge.pending}项，相关未读更新${item.badge.updates}项`}>{item.badge.pending>99?"99+":item.badge.pending||"•"}</span>:null}</button>)}</div></div>
 <div className="project-module-navigation" id="project-module-navigation" role="tabpanel" aria-labelledby={project?`project-tab-${project.id}`:'project-tabs-label'}>{project?<><strong className="project-sidebar-name">{project.name}</strong><nav aria-label="项目二级导航">{projectNav.filter(([,key])=>!key||(key==='transfer'?project.capabilities.transfer:key==='manage'?can('business.accounts'):(key==='cross'?project.capabilities.cross:project.capabilities[key]))).map(globalButton)}</nav></>:<p>选择项目<br/>开始工作</p>}</div></section>
 <nav className="project-system-nav" aria-label="系统操作与全局配置"><small>系统与全局配置</small><div>{visibleGlobal.filter(([name])=>!['系统首页','通知公告','工作报备'].includes(name)).map(globalButton)}</div></nav>
 </aside><section ref={workspaceRef} className="project-workspace"><header ref={topbarRef} className="project-topbar"><button className="navigation-toggle" aria-controls="primary-navigation" aria-expanded={!collapsed} onClick={()=>setCollapsed(value=>!value)} aria-label={collapsed?"展开导航":"收起导航"}>{collapsed?"☰ 展开导航":"☰ 收起导航"}</button><div><small>{globalPage?'系统外层':`当前项目：${project?.name??''}`}</small><h1>{nav}</h1></div><span>{user?.displayName}</span><button onClick={async()=>{if(!await canLeavePage())return;await fetch('/api/auth/logout',{method:'POST'});clearBusinessContext();window.location.reload();}}>退出登录</button></header>{message?<div role={messageTone==='error'?'alert':'status'} className={`toast global-toast ${messageTone}`}><span>{messageTone==='error'?'!':'✓'}</span><strong>{message}</strong><button aria-label="关闭提示" onClick={()=>setMessage('')}>×</button></div>:null}{error?<div className="project-load-error" role="alert"><span>{error}</span><button type="button" onClick={()=>void refresh().catch(e=>setError(e.message))}>重新加载</button></div>:null}{badgeWarning?<p className="project-badge-warning" role="status">部分项目提醒暂不可用，项目入口仍可正常使用。</p>:null}<div className="project-content" key={project?.projectType==='cross_border'&&!globalPage?`cross-${project.id}`:`${context?.accountId??'global'}-${nav}-${epoch}`}>
 {nav==='系统首页'?<section className="panel project-module"><h2>选择项目开始工作</h2><p>公告和日报在系统外层使用；项目内的产品、素材、内容和发布业务分别隔离。切换项目后统一进入该项目工作台。</p>{can('notice.view')?<><h3>待处理通知</h3>{noticeTasks.length?noticeTasks.map(item=><button className="project-pending-notice" key={item.id} onClick={()=>setNoticeTarget(item.id)}>{item.title} · {item.requiresReply?'待回复':'待确认已阅'}</button>):<p>暂无待处理通知</p>}</>:null}<div className="project-cards">{projects.map(project=><button key={project.id} onClick={()=>enter(project.id)}><strong>{project.name}</strong><span>进入项目 →</span></button>)}</div>{!projects.length?<p>尚未分配项目，可使用有权限的外层功能。请联系主账号开放项目入口。</p>:null}</section>:
 nav==='员工同步管理'&&canMaintain?<EmployeeSyncAdmin/>:nav==='全平台业务清理'&&canMaintain?<AdminMaintenance/>:nav==='项目管理'?<ProjectManagement onChanged={()=>void refresh()} notify={notify}/>:
 nav==='中转站'&&project?<TransferStation project={project.id}/>:project?.projectType==='cross_border'&&!globalPage?<CrossWorkspace requestedScope={targetCode} requestEpoch={epoch} module={nav} projectId={project.id} notify={notify} navigate={global}/>:
 nav==='项目工作台'?<ProjectDashboard navigate={global} displayName={user?.displayName??""} capabilities={project?.capabilities??{}} canManageRecommendations={Boolean(can('content.feature')||can('review.recommend'))} notify={notify}/>:
 nav==='发布管理'?<TargetPublishing notify={notify}/>:
 nav==='数据统计'?<ProjectStatistics/>:
 <ModuleView name={nav} notify={notify} navigate={global} platformIcons={icons} setPlatformIcons={setIcons} versionTarget={targetCode} contentTarget={targetCode}/>}
 </div>{noticeTarget?<DashboardNoticeDialog id={noticeTarget} onClose={()=>setNoticeTarget(null)} onChanged={loadNotices} notify={notify}/>:null}</section><ViewportTables/></main>;
}
